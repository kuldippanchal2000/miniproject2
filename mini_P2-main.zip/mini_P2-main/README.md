# mini_P2
web development mini project for blogging site
